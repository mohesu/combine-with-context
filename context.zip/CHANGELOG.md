# Change Log

All notable changes to the "copy-with-context" extension will be documented in this file.

## [2.2.4] - 08-15-2025

- Cursor support for the extension

## [1.5.0] - 05-06-2025

### Added

- Interactive UI for editing the excluded files/folders. from command pallete (shift+cmd+p) and look for "Copy Context: Edit Excluded Paths", this will open the quick pick dialogue to add/remove files
- Reduced extension bundle size by 93%
- Performance optimizations with caching of excluded paths